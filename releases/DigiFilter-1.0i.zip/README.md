# DigiFilter 1.0i

Extra per-track filter modes for the Elektron **Digitakt mk1 (OS 1.53)**: on top
of the stock `OFF / LP / HP / EQ:1..5`, it adds

| TYPE | mode | what it is |
|---|---|---|
| 8 | **BP** | band pass (state-variable filter) |
| 9 | **BP2** | a wider band pass (about half the resonance) |
| 10 | **COMB** | feedback comb, delay from FREQ, feedback from RESO |
| 11 | **TRASH** | second comb at half the delay (a higher harmonic series) |

Each mode uses that track's own FREQ, RESO and **filter envelope**, exactly like
the stock types; while COMB/TRASH is selected the **second FLTR page**'s Base /
Width / Env Delay / SRR knobs become delay, harmonics, damping and feedback
trim.

More in the project README: <https://github.com/DigiAlchemydsp/DigiFilter>.

> **Known issue.** BP (TYPE 8) can clip at some frequencies: the band-pass SVF
> has no output saturation, so high RESO near the pass-band can exceed full
> scale. Back off RESO/ENV or use BP2.
>
> **Cosmetic.** The FLTR page's FREQ/RES **response curve** still draws the
> stock shapes for the new types. Digitakt **mk1 only**; Digitakt II is out of
> scope.

## What's in this package

| path | |
|---|---|
| `elemods/digifilter-1.0i.elemod` | the mod, ready to install |
| `sources/digifilter/` | the sources to build it: `mod.json`, `filter.c`, `filter_dsp.s`, `filter_glue.s`, `filter_tables.h` (plus the project README and RE notes) |
| `LICENSE` | GPL-2.0-or-later |

No Elektron firmware is included or distributed. elekloader builds the custom OS
on your own machine, from your own stock OS file and the mods you pick.

## Install

You need four things:

1. **elekloader** — the mod loader/build tool.
   - **Windows:** download `elekloader-<version>-windows.zip` from
     [elekloader's releases](https://github.com/irpina/elekloader/releases/latest),
     unzip it and run `elekloader.exe`. The core mod it needs is built in.
   - **Other systems:** run elekloader from source with Python 3.9 or newer
     (see [its README](https://github.com/irpina/elekloader#install)).
2. **core 2.1** (`core-2.1.elemod`) — every linkable mod needs `core`. It is
   built in on the Windows app; from source, get `core-2.1.elemod` from
   elekloader's releases, or build elekloader's `mods/core`.
3. **This mod** — `elemods/digifilter-1.0i.elemod`.
4. **The stock OS file** — `Digitakt_OS1.53.syx`, from
   [Elektron's Digitakt downloads](https://www.elektron.se/support-downloads/digitakt).
   elekloader recognises the file by its hash.

In elekloader's window:

1. **Change stock firmware...** (top right): choose `Digitakt_OS1.53.syx`.
2. **+ Install from file...**: choose `core-2.1.elemod`, then
   `digifilter-1.0i.elemod`. (On the Windows app, core is already there.)
3. **Tick core and digifilter.** The check below the list should say
   "No conflicts ... Ready to build". To add
   [digihealth](https://github.com/irpina/digihealth) (FAST AUDIO and SYSTEM
   INFO), install and tick it as well.
4. **OS version shown**: the 4 characters the unit will show, for example `2.0t`.
5. **BUILD FIRMWARE**, and save the `.syx`. elekloader verifies it before
   writing it.

Flash it with Elektron Transfer, as for any OS update
([Elektron's instructions](https://support.elektron.se/support/solutions/articles/43000662890-how-to-update-your-device)):

1. Connect the unit over USB.
2. In Transfer, select the unit and **Connect**.
3. Drag the `.syx` onto **Drop files here**.
4. Press **YES** on the unit.

Don't turn it off until the upgrade is done.

Or on the command line (elekloader from source):

```sh
python -m elekloader.patch --stock Digitakt_OS1.53.syx \
    --mod core-2.1.elemod --mod digifilter-1.0i.elemod \
    --out Digitakt_OS1.53-digifilter.syx --version 2.0t
```

**Recovery:** elekloader never changes the bootloader, so the stock OS file
always restores the unit. Hold **FUNC** while powering on for the startup menu,
and press **TRIG 4** for OS UPGRADE. Then send the stock `.syx` with Transfer's
legacy OS upgrade mode.

## Build it from source

Needs the m68k cross toolchain (m68k binutils and gcc; on Debian or Ubuntu,
`apt install binutils-m68k-linux-gnu gcc-m68k-linux-gnu`; on Windows, inside
WSL or SysGCC) and an elekloader checkout. Set up the shell, then build:

```sh
export PATH="<m68k-elf bin>:$PATH"          # e.g. C:\SysGCC\m68k-elf\bin on Windows
export ELEKLOADER_CROSS=m68k-elf-
export PYTHONPATH="<elekloader checkout>"

cd sources/digifilter
python -m elekloader.sdk.build . --stock <Digitakt_OS1.53.syx>
python -m elekloader.lint  out/digifilter-1.0i.elemod --stock <Digitakt_OS1.53.syx> --with <core-2.1.elemod>
```

That must print `BUILT`, then `OK: links as core 2.1 ...`. See the project
README for the full build/lint/patch and testing commands.

## Licence

GPL-2.0-or-later. DigiFilter is free software: you can redistribute it and/or
modify it under the terms of the GNU General Public License as published by the
Free Software Foundation, either version 2 of the License, or (at your option)
any later version. It is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE. See [LICENSE](LICENSE) for version 2.

Not affiliated with Elektron. Digitakt is a trademark of Elektron. Custom
firmware is at your own risk.
